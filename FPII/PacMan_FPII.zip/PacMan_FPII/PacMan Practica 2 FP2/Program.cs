﻿using System;

namespace PacMan_Practica_2_FP2
{
    class Program
    {
        static void Main(string[] args)
        {
            Tablero t = new Tablero(...);
            t.Dibuja();
            int lap = 200; // retardo para bucle ppal
            char c =’ ’;
            while (...) {
                // input de usuario
                LeeInput(ref c);
                // procesamiento del input
                if (c !=’ ’ && t.CambiaDir(c)) c =’ ’;
                t.MuevePacman();
                // IA de los fantasmas: TODO
                // rederizado
                t.Dibuja();
                // retardo
                System.Threading.Thread.Sleep(lap);
            }
        }
    }
}
