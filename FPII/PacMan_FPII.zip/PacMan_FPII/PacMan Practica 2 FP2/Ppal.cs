﻿using System;

namespace PacMan_Practica_2_FP2
{
    class Ppal
    {



    }
}
